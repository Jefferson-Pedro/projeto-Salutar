package br.com.isiflix.salutar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalutarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalutarApplication.class, args);
	}

}
